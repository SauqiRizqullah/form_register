from django.db import models

# Create your models here.

class Employee(models.Model):
    fullname = models.CharField(max_length=100)
    alamat = models.CharField(max_length=255)
    nomoktp = models.IntegerField()

class Pendidikan(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='pendidikans')
    nama_sekolah = models.CharField(max_length=255)
    jurusan = models.CharField(max_length=100)
    tahun_masuk = models.IntegerField()
    tahun_lulus = models.IntegerField()

    def clean(self):
        # Logika validasi: Tahun lulus tidak boleh kurang dari tahun masuk
        if self.tahun_lulus < self.tahun_masuk:
            raise ValidationError('Tahun lulus tidak boleh kurang dari tahun masuk.')

    def __str__(self):
        return f"{self.nama_sekolah} - {self.jurusan} ({self.tahun_masuk} - {self.tahun_lulus})"